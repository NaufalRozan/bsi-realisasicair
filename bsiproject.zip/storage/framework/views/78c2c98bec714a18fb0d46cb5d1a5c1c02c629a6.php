

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<!-- <html> -->

<head>

<body>
    <div class="container">
        <div class="container mt-3">

            <?php if(session('Sukses')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('Sukses')); ?>

            </div>
            <?php endif; ?>

            <div class="row">
                <h1>Data</h1>
                <table class="table">

                    <div class="col-11 my-4" align="right">
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary btn-sm float-right" data-toggle="modal" data-target="#exampleModal">
                            Tambah Data
                        </button>
                    </div>

                </table>
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th>Nama Marketing</th>
                            <th>Realisasi_Cair</th>
                            <th>Tanggal</th>
                            <th>Total Pencairan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <?php $__currentLoopData = $keseluruhan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keseluruhan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($keseluruhan->name); ?></td>
                            <td><?php echo e($keseluruhan->Realisasi_Cair); ?></td>
                            <td><?php echo e($keseluruhan->tanggal); ?></td>
                            <td><?php echo e($keseluruhan->Total_Pencairan); ?></td>
                            <td>
                                <a href="/keseluruhan/<?php echo e($keseluruhan->id); ?>/edit" class="btn btn-warning bgn-sm">Edit</a>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
            </script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous">
            </script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous">
            </script>
        </div>

</body>

</html>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bsiproject\resources\views/keseluruhan/index.blade.php ENDPATH**/ ?>